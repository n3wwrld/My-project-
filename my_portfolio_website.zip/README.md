# My Portfolio Website

A beginner-friendly personal portfolio built with HTML and CSS.

## Files
- `index.html` — the website content and sections
- `style.css` — colours, layout, and responsive styling

## How to customise
1. Open `index.html`.
2. Replace `Your Name` with your name.
3. Update the About and Skills text so it describes you.
4. Replace `your.email@example.com` with your email address.
5. Save both files.

## How to publish with GitHub Pages
1. Sign in to GitHub and create a new repository (for example, `my-portfolio`).
2. Upload `index.html`, `style.css`, and `README.md` to the repository's main branch.
3. Open the repository's **Settings** → **Pages**.
4. Under the build/deployment section, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait a few minutes. GitHub will show your website link in the Pages section.

This project uses only HTML and CSS; no installation or build step is required.
